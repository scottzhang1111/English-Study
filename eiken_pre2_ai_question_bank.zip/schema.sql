
-- EIKEN Pre-2 AI Question Bank Schema
-- Import the CSV files or use the included SQLite database directly.

CREATE TABLE IF NOT EXISTS passages (
  passage_id TEXT PRIMARY KEY,
  set_id TEXT NOT NULL,
  passage_no INTEGER NOT NULL,
  genre TEXT NOT NULL,
  title TEXT,
  passage_text TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS question_bank (
  question_id TEXT PRIMARY KEY,
  set_id TEXT NOT NULL,
  question_no INTEGER NOT NULL,
  section TEXT NOT NULL,
  question_type TEXT NOT NULL,
  passage_id TEXT,
  prompt TEXT NOT NULL,
  option_A TEXT NOT NULL,
  option_B TEXT NOT NULL,
  option_C TEXT NOT NULL,
  option_D TEXT NOT NULL,
  correct_option TEXT NOT NULL CHECK (correct_option IN ('A','B','C','D')),
  explanation_zh TEXT,
  explanation_ja TEXT,
  difficulty TEXT,
  skill_tag TEXT,
  target_vocab TEXT,
  source_style TEXT,
  FOREIGN KEY (passage_id) REFERENCES passages(passage_id)
);

CREATE TABLE IF NOT EXISTS students (
  student_id TEXT PRIMARY KEY,
  student_name TEXT NOT NULL,
  grade TEXT,
  target_level TEXT,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS attempts (
  attempt_id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL,
  set_id TEXT NOT NULL,
  attempt_date TEXT,
  total_questions INTEGER DEFAULT 30,
  correct_count INTEGER,
  score_rate REAL,
  time_minutes INTEGER,
  notes TEXT,
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);

CREATE TABLE IF NOT EXISTS student_answers (
  answer_id TEXT PRIMARY KEY,
  attempt_id TEXT,
  student_id TEXT,
  set_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  student_answer TEXT CHECK (student_answer IN ('A','B','C','D') OR student_answer IS NULL OR student_answer=''),
  correct_option TEXT NOT NULL,
  is_correct INTEGER,
  answered_at TEXT,
  review_flag TEXT,
  review_note TEXT,
  FOREIGN KEY (question_id) REFERENCES question_bank(question_id),
  FOREIGN KEY (attempt_id) REFERENCES attempts(attempt_id),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);

CREATE VIEW IF NOT EXISTS v_attempt_summary AS
SELECT
  a.attempt_id,
  a.student_id,
  s.student_name,
  a.set_id,
  COUNT(sa.question_id) AS answered_questions,
  SUM(CASE WHEN sa.student_answer = qb.correct_option THEN 1 ELSE 0 END) AS correct_count,
  ROUND(100.0 * SUM(CASE WHEN sa.student_answer = qb.correct_option THEN 1 ELSE 0 END) / COUNT(sa.question_id), 1) AS score_percent
FROM attempts a
LEFT JOIN students s ON a.student_id = s.student_id
LEFT JOIN student_answers sa ON a.attempt_id = sa.attempt_id
LEFT JOIN question_bank qb ON sa.question_id = qb.question_id
GROUP BY a.attempt_id, a.student_id, s.student_name, a.set_id;
