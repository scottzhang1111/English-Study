# EIKEN Pre-2 AI Question Bank

Created: 2026-05-10

## Contents
- question_bank.csv: 10 sets × 30 questions = 300 original EIKEN Pre-2 style questions.
- passages.csv: 50 reading passages used by the reading questions.
- students.csv: student master template.
- attempts.csv: test attempt / score summary template.
- student_answers_template.csv: per-question answer tracking template.
- eiken_pre2_ai_question_bank.sqlite: ready-to-use SQLite database with the same tables.
- schema.sql: database schema and summary view.

## Test structure per set
- Questions 1-10: 短句填空 / sentence fill
- Questions 11-15: 对话完成 / dialogue completion
- Questions 16-30: 阅读理解 / five passages × three questions

## Recommended app flow
1. Pick a set_id, for example SET01.
2. Show all rows from question_bank where set_id = 'SET01', joining passages when passage_id is not empty.
3. Save each child answer to student_answers.
4. Mark is_correct = 1 when student_answer equals correct_option, otherwise 0.
5. Use wrong questions where is_correct = 0 as the child’s review queue.

## Notes
All questions and passages are newly created and are not copied from past exam PDFs.
